import MethodsExercise.Methods;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        Methods.signOfInteger(5);
//        Methods.signOfInteger(0);
//        Methods.signOfInteger(-2);

//        Methods.grades(2.2);
//        Methods.grades(0);
//        Methods.grades(6.6);
//        Methods.grades(6);
//        Methods.grades(4);
//        Methods.grades(3.33);
//
//        Methods.printingTriangle(4);
//
//        Methods.basicCalculation("add", 1, 2);
//        Methods.basicCalculation("subtract", 1, 2);
//        Methods.basicCalculation("divide", 1, 2);
//        Methods.basicCalculation("multiply", 2, 2);
//
//        Methods.calculateOrderPrice("water", 5);
//        Methods.calculateOrderPrice("keyboard", 5);
//
//        System.out.println(Methods.repeatString("", 5));

//        Methods.getMax("string", "a", "b");
//        //Methods.getMax("int", "a", "b");
//        Methods.getMax("char", "a", "b");
//        //Methods.getMax("char", "ab", "bb");
//        Methods.getMax("int", "1", "2");
//        Methods.getMax("int", "2", "16");
//        Methods.getMax("char", "a", "z");
//        Methods.getMax("string", "Ivan", "Todor");
//
//
//        Methods.validatePassword("logIn");
//        System.out.println();
//        Methods.validatePassword("MyPass12");
//        System.out.println();
//        Methods.validatePassword("PaSSS.");
//
//
//        Methods.mathOperations(5, 5, '*');
//        Methods.mathOperations(4, 8, '+');
//
//        System.out.println(Methods.multiplyEvensByOdds(12345));

    }
}