package com.sirma.finalexam.matchanalyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchanalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
