package com.sirma.finalexam.matchanalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchanalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatchanalyzerApplication.class, args);
	}

}
