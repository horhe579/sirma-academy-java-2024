package com.sirma.interfaces;

public interface Employable {
    String getName();
    double getSalary();
}
