public class UpTo1000EndingIn7 {
    public static void main(String[] args) {
        for (int i = 7; i <= 1000; i += 10) {
            System.out.println(i);
        }
    }
}
